---
name: Bug report
about: Create a report to help improve the repo
title: "[BUG] "
labels: bug
---

## Description
What happened?

## Steps to reproduce
1.
2.
3.

## Expected behavior
What did you expect?

## Environment
- OS:
- Python:
- Terraform:
